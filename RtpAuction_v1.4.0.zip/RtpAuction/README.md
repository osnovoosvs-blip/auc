# RtpAuction (Paper 1.21+, Java 21)

Плагин: **/rtp** (случайная телепортация), **/spawn** + **/setspawn** и **/ah** (аукцион игроков с GUI).
Нужен Vault + любой плагин экономики для аукциона и платного RTP.

## Сборка
    mvn clean package
Готовый jar: `target/RtpAuction-1.4.0.jar` → в папку `plugins/`.

## Команды
| Команда | Что делает |
|---|---|
| /rtp | случайная телепортация (кулдаун, задержка, цена — в config.yml) |
| /spawn | телепорт на спавн (задержка/кулдаун — в config.yml) |
| /setspawn | установить спавн в вашей позиции (админ) |
| (авто) таб-лист | шапка/подвал: ник, баланс, пинг, онлайн, TPS — блок `tab:` в config.yml |
| (авто) деньги за мобов | суммы по типам мобов — блок `mob-rewards:` в config.yml |
| /ah | открыть аукцион (ЛКМ по лоту — купить) |
| /ah sell <цена> | выставить предмет из основной руки |
| /ah mine | мои лоты (ЛКМ — снять) |
| /ah claim | забрать просроченные/возвращённые предметы |
| /ahnpc set | поставить NPC-аукциониста на своё место (админ); ПКМ по нему открывает аукцион |
| /ahnpc remove | убрать NPC (админ) |
| /ah reload | перезагрузка конфига (админ) |

## Права
rtpauction.rtp, rtpauction.rtp.bypass, rtpauction.spawn, rtpauction.spawn.set,
rtpauction.spawn.bypass, rtpauction.mobreward, rtpauction.auction,
rtpauction.auction.unlimited, rtpauction.auction.admin, rtpauction.npc

## Скин NPC
NPC — это Mannequin (Minecraft 1.21.9+). Ресурспак со скином **уже встроен в плагин**: он сам раздаётся
и отправляется игрокам при входе. Достаточно положить jar в `plugins/` и выполнить `/ahnpc set`.
Единственное требование — открытый TCP-порт `resource-pack.port` (по умолчанию 25580).
Если порт открыть нельзя: выложите AuctionNpcSkin_resourcepack.zip на свой хостинг и укажите ссылку в `resource-pack.url`,
либо используйте подписанный скин с mineskin.org (`npc.skin.value` + `signature`).
