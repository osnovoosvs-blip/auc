package dev.rtpauction;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;

import java.io.File;
import java.io.IOException;

/** NPC-аукционист на спавне: ПКМ открывает аукцион. Позиция хранится в npc.yml, сам моб помечен тегом rtpauction_npc. */
public final class NpcManager implements Listener {
    private final RtpAuctionPlugin plugin;
    private final File file;
    private static final String TAG = "rtpauction_npc";

    public NpcManager(RtpAuctionPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "npc.yml");
    }

    private boolean isNpc(Entity e) {
        return e.getScoreboardTags().contains(TAG);
    }

    /** Ставит NPC в указанной точке (старый удаляется). Лицом туда же, куда смотрит игрок. */
    public void place(Location loc) {
        remove();
        Location at = loc.clone();
        at.setX(at.getBlockX() + 0.5);
        at.setZ(at.getBlockZ() + 0.5);
        at.setPitch(0);

        String type = plugin.getConfig().getString("npc.type", "MANNEQUIN").toUpperCase();
        Entity ent = type.equals("MANNEQUIN") ? spawnMannequin(at) : null;
        if (ent == null) ent = spawnMob(at, type);

        ent.addScoreboardTag(TAG);
        ent.setPersistent(true);
        ent.setInvulnerable(true);
        ent.setSilent(true);
        ent.setGravity(false);
        ent.customName(plugin.messages().legacy(plugin.getConfig().getString("npc.name", "&6&lАукцион")));
        ent.setCustomNameVisible(true);

        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("world", at.getWorld().getName());
        cfg.set("x", at.getX());
        cfg.set("y", at.getY());
        cfg.set("z", at.getZ());
        try {
            plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Не удалось сохранить npc.yml: " + ex.getMessage());
        }
    }

    /** Обычный моб (VILLAGER и т.п.) — без скина. */
    private Entity spawnMob(Location at, String typeName) {
        EntityType type;
        try {
            type = EntityType.valueOf(typeName);
        } catch (IllegalArgumentException ex) {
            type = EntityType.VILLAGER;
        }
        return at.getWorld().spawnEntity(at, type, org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.CUSTOM, e -> {
            if (e instanceof Villager v) {
                v.setProfession(Villager.Profession.NITWIT);
            }
            if (e instanceof org.bukkit.entity.LivingEntity le) {
                le.setAI(false);
                le.setRemoveWhenFarAway(false);
                le.setCollidable(false);
            }
        });
    }

    /** Манекен со скином (Minecraft 1.21.9+). Создаётся командой summon, чтобы не зависеть от версии API. */
    private Entity spawnMannequin(Location at) {
        var c = plugin.getConfig();
        String model = c.getString("npc.skin.model", "slim");
        String texture = c.getString("npc.skin.texture", "");
        if (texture.isBlank() && c.getBoolean("resource-pack.enabled", true)) {
            texture = "rtpauction:entity/auction_npc"; // встроенный ресурспак плагина
        }
        String value = c.getString("npc.skin.value", "");
        String signature = c.getString("npc.skin.signature", "");
        String desc = c.getString("npc.description", "ПКМ — открыть аукцион");

        StringBuilder profile = new StringBuilder("{model:\"" + model + "\"");
        if (!value.isBlank()) {
            // подписанная текстура (MineSkin): нужен id и name, иначе клиент не применит properties
            java.util.UUID id = java.util.UUID.nameUUIDFromBytes("rtpauction-npc".getBytes());
            long m = id.getMostSignificantBits(), l = id.getLeastSignificantBits();
            profile.append(",name:\"AuctionNpc\",id:[I;").append((int) (m >> 32)).append(',').append((int) m)
                    .append(',').append((int) (l >> 32)).append(',').append((int) l).append("]")
                    .append(",properties:[{name:\"textures\",value:\"").append(esc(value)).append('"');
            if (!signature.isBlank()) profile.append(",signature:\"").append(esc(signature)).append('"');
            profile.append("}]");
        } else if (!texture.isBlank()) {
            profile.append(",texture:\"").append(esc(texture)).append('"');
        }
        profile.append('}');

        String nbt = String.format(java.util.Locale.ROOT,
                "{Tags:[\"%s\"],Rotation:[%.1ff,0.0f],immovable:1b,profile:%s,%s}",
                TAG, at.getYaw(), profile,
                desc.isBlank() ? "hide_description:1b" : "description:{text:\"" + esc(desc) + "\",color:\"yellow\"}");
        String cmd = String.format(java.util.Locale.ROOT, "execute in %s run summon minecraft:mannequin %.2f %.2f %.2f %s",
                at.getWorld().getKey(), at.getX(), at.getY(), at.getZ(), nbt);

        boolean ok = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        if (!ok) {
            plugin.getLogger().warning("Не удалось создать Mannequin (нужен Minecraft 1.21.9+). Использую жителя.");
            return null;
        }
        for (Entity e : at.getWorld().getNearbyEntities(at, 1, 2, 1)) {
            if (isNpc(e)) return e;
        }
        return null;
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    /** Удаляет NPC. Возвращает true, если что-то было удалено. */
    public boolean remove() {
        if (!file.exists()) return false;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        boolean removed = false;
        var world = Bukkit.getWorld(cfg.getString("world", ""));
        if (world != null) {
            Location loc = new Location(world, cfg.getDouble("x"), cfg.getDouble("y"), cfg.getDouble("z"));
            world.getChunkAt(loc); // прогрузить чанк, чтобы увидеть моба
            for (Entity e : world.getNearbyEntities(loc, 3, 3, 3)) {
                if (isNpc(e)) {
                    e.remove();
                    removed = true;
                }
            }
        }
        file.delete();
        return removed;
    }

    // ---------- события ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onInteract(PlayerInteractEntityEvent e) {
        if (!isNpc(e.getRightClicked())) return;
        e.setCancelled(true); // не открывать торговлю жителя
        if (e.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        open(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteractAt(PlayerInteractAtEntityEvent e) {
        if (isNpc(e.getRightClicked())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent e) {
        if (isNpc(e.getEntity())) e.setCancelled(true);
    }

    private void open(Player p) {
        if (!p.hasPermission("rtpauction.auction")) {
            plugin.messages().send(p, "no-permission");
            return;
        }
        if (plugin.economy() == null) {
            plugin.messages().send(p, "ah-no-economy");
            return;
        }
        plugin.gui().open(p, AuctionGui.Mode.ALL, 0);
    }
}
