package dev.rtpauction;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Таб-лист: шапка/подвал (и, по желанию, имя в списке) с ником, балансом, пингом.
 * Плейсхолдеры: {player} {money} {ping} {ping_colored} {online} {max} {tps} {world}
 */
public final class TabManager implements Listener {
    private final RtpAuctionPlugin plugin;
    private boolean listNameApplied;

    public TabManager(RtpAuctionPlugin plugin) {
        this.plugin = plugin;
    }

    /** Таймер читает конфиг на каждом тике обновления, поэтому /ah reload работает без перезапуска. */
    public void start() {
        schedule();
    }

    private void schedule() {
        long period = Math.max(5L, plugin.getConfig().getLong("tab.update-ticks", 40L));
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            try {
                updateAll();
            } catch (Exception ex) {
                plugin.getLogger().warning("Ошибка обновления таба: " + ex.getMessage());
            }
            schedule();
        }, period);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && plugin.getConfig().getBoolean("tab.enabled", true)) update(p);
        }, 5L);
    }

    private void updateAll() {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("tab.enabled", true)) return;

        boolean listName = c.getBoolean("tab.list-name.enabled", false);
        for (Player p : Bukkit.getOnlinePlayers()) update(p);
        if (!listName && listNameApplied) {
            for (Player p : Bukkit.getOnlinePlayers()) p.playerListName(null);
            listNameApplied = false;
        }
    }

    private void update(Player p) {
        FileConfiguration c = plugin.getConfig();
        p.sendPlayerListHeaderAndFooter(
                lines(c.getStringList("tab.header"), p),
                lines(c.getStringList("tab.footer"), p));

        if (c.getBoolean("tab.list-name.enabled", false)) {
            p.playerListName(plugin.messages().legacy(
                    fill(c.getString("tab.list-name.format", "{player}"), p)));
            listNameApplied = true;
        }
    }

    private Component lines(List<String> raw, Player p) {
        List<Component> out = new ArrayList<>();
        for (String line : raw) out.add(plugin.messages().legacy(fill(line, p)));
        return Component.join(JoinConfiguration.newlines(), out);
    }

    private String fill(String s, Player p) {
        FileConfiguration c = plugin.getConfig();
        int ping = p.getPing();
        int good = c.getInt("tab.ping-good", 100);
        int ok = c.getInt("tab.ping-ok", 200);
        String color = ping < good ? "&a" : ping < ok ? "&e" : "&c";

        double[] tps = Bukkit.getTPS();
        return s.replace("{player}", p.getName())
                .replace("{money}", money(p))
                .replace("{ping_colored}", color + ping)
                .replace("{ping}", String.valueOf(ping))
                .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()))
                .replace("{max}", String.valueOf(Bukkit.getMaxPlayers()))
                .replace("{tps}", String.format(Locale.US, "%.1f", Math.min(20.0, tps[0])))
                .replace("{world}", p.getWorld().getName());
    }

    private String money(Player p) {
        Economy eco = plugin.economy();
        if (eco == null) return plugin.getConfig().getString("tab.no-economy-text", "-");
        return eco.format(eco.getBalance(p));
    }
}
