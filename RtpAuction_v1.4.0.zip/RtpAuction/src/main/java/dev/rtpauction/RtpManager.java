package dev.rtpauction;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public final class RtpManager {
    private static final Set<Material> UNSAFE = EnumSet.of(
            Material.LAVA, Material.MAGMA_BLOCK, Material.CACTUS, Material.FIRE, Material.SOUL_FIRE,
            Material.CAMPFIRE, Material.SOUL_CAMPFIRE, Material.SWEET_BERRY_BUSH, Material.POWDER_SNOW,
            Material.POINTED_DRIPSTONE, Material.WITHER_ROSE);

    private final RtpAuctionPlugin plugin;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> pending = new HashSet<>();
    private final Random random = new Random();

    public RtpManager(RtpAuctionPlugin plugin) {
        this.plugin = plugin;
    }

    public void request(Player player) {
        FileConfiguration c = plugin.getConfig();
        Messages m = plugin.messages();
        UUID id = player.getUniqueId();
        World world = player.getWorld();

        if (!c.getStringList("rtp.worlds").contains(world.getName())) {
            m.send(player, "rtp-world-disabled");
            return;
        }
        if (pending.contains(id)) {
            m.send(player, "rtp-already");
            return;
        }
        boolean bypass = player.hasPermission("rtpauction.rtp.bypass");
        if (!bypass) {
            long left = cooldowns.getOrDefault(id, 0L) - System.currentTimeMillis();
            if (left > 0) {
                m.send(player, "rtp-cooldown", "seconds", String.valueOf((left + 999) / 1000));
                return;
            }
        }
        double cost = 0;
        Economy eco = plugin.economy();
        if (!bypass && eco != null) {
            cost = c.getDouble("rtp.cost", 0.0);
            if (cost > 0 && !eco.has(player, cost)) {
                m.send(player, "rtp-no-money", "cost", eco.format(cost));
                return;
            }
        }

        int warmup = bypass ? 0 : c.getInt("rtp.warmup-seconds", 0);
        pending.add(id);
        if (warmup <= 0) {
            attempt(player, world, cost, 0);
            return;
        }
        m.send(player, "rtp-warmup", "seconds", String.valueOf(warmup));
        Location start = player.getLocation().clone();
        final double fCost = cost;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) {
                pending.remove(id);
                return;
            }
            Location now = player.getLocation();
            if (now.getWorld() != start.getWorld() || now.distanceSquared(start) > 1.0) {
                pending.remove(id);
                m.send(player, "rtp-moved");
                return;
            }
            attempt(player, world, fCost, 0);
        }, warmup * 20L);
    }

    private void attempt(Player player, World world, double cost, int tries) {
        FileConfiguration c = plugin.getConfig();
        UUID id = player.getUniqueId();
        if (!player.isOnline()) {
            pending.remove(id);
            return;
        }
        if (tries >= c.getInt("rtp.max-attempts", 15)) {
            pending.remove(id);
            plugin.messages().send(player, "rtp-failed");
            return;
        }

        WorldBorder border = world.getWorldBorder();
        Location center = border.getCenter();
        double maxR = Math.max(1, Math.min(c.getDouble("rtp.max-radius", 5000), border.getSize() / 2 - 2));
        double minR = Math.min(c.getDouble("rtp.min-radius", 500), maxR);
        double angle = random.nextDouble() * Math.PI * 2;
        double dist = minR + random.nextDouble() * (maxR - minR);
        int x = (int) Math.floor(center.getX() + Math.cos(angle) * dist);
        int z = (int) Math.floor(center.getZ() + Math.sin(angle) * dist);

        world.getChunkAtAsync(x >> 4, z >> 4)
                .thenAccept(chunk -> Bukkit.getScheduler().runTask(plugin, () -> {
                    Location safe = findSafe(world, x, z);
                    if (safe == null) attempt(player, world, cost, tries + 1);
                    else finish(player, safe, cost);
                }))
                .exceptionally(ex -> {
                    Bukkit.getScheduler().runTask(plugin, () -> attempt(player, world, cost, tries + 1));
                    return null;
                });
    }

    private void finish(Player player, Location safe, double cost) {
        UUID id = player.getUniqueId();
        Messages m = plugin.messages();
        Economy eco = plugin.economy();
        boolean charged = cost > 0 && eco != null;
        if (charged && !eco.withdrawPlayer(player, cost).transactionSuccess()) {
            pending.remove(id);
            m.send(player, "rtp-no-money", "cost", eco.format(cost));
            return;
        }
        safe.setYaw(player.getLocation().getYaw());
        safe.setPitch(player.getLocation().getPitch());
        player.teleportAsync(safe).thenAccept(ok -> Bukkit.getScheduler().runTask(plugin, () -> {
            pending.remove(id);
            if (!ok) {
                if (charged) eco.depositPlayer(player, cost);
                m.send(player, "rtp-failed");
                return;
            }
            long cd = plugin.getConfig().getLong("rtp.cooldown-seconds", 0) * 1000L;
            cooldowns.put(id, System.currentTimeMillis() + cd);
            m.send(player, "rtp-success",
                    "x", String.valueOf(safe.getBlockX()),
                    "y", String.valueOf(safe.getBlockY()),
                    "z", String.valueOf(safe.getBlockZ()));
        }));
    }

    private Location findSafe(World world, int x, int z) {
        if (!world.getWorldBorder().isInside(new Location(world, x, 64, z))) return null;
        if (world.getEnvironment() == World.Environment.NORMAL) {
            int y = world.getHighestBlockYAt(x, z);
            return check(world.getBlockAt(x, y, z));
        }
        int top = world.getEnvironment() == World.Environment.NETHER ? 120 : world.getMaxHeight() - 3;
        for (int y = top; y > world.getMinHeight() + 1; y--) {
            Location loc = check(world.getBlockAt(x, y, z));
            if (loc != null) return loc;
        }
        return null;
    }

    private Location check(Block ground) {
        Material type = ground.getType();
        if (!type.isSolid() || UNSAFE.contains(type) || Tag.LEAVES.isTagged(type)) return null;
        Block feet = ground.getRelative(BlockFace.UP);
        Block head = feet.getRelative(BlockFace.UP);
        if (!feet.isPassable() || feet.isLiquid() || !head.isPassable() || head.isLiquid()) return null;
        if (UNSAFE.contains(feet.getType())) return null;
        return feet.getLocation().add(0.5, 0, 0.5);
    }
}
