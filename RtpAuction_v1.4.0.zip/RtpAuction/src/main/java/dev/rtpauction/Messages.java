package dev.rtpauction;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;

/** Сообщения из config.yml. Подстановки: send(to, "key", "name", "value", ...). */
public final class Messages {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final RtpAuctionPlugin plugin;

    public Messages(RtpAuctionPlugin plugin) {
        this.plugin = plugin;
    }

    public String raw(String key, String... kv) {
        String s = plugin.getConfig().getString("messages." + key); // дефолт из jar подставится сам
        if (s == null) s = key;
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        }
        return s;
    }

    public Component component(String key, String... kv) {
        return LEGACY.deserialize(raw(key, kv));
    }

    /** Компонент без курсива (для названий и описаний предметов). */
    public Component plain(String key, String... kv) {
        return component(key, kv).decoration(TextDecoration.ITALIC, false);
    }

    /** Готовая строка с &-цветами → компонент без курсива. */
    public Component legacy(String raw) {
        return LEGACY.deserialize(raw).decoration(TextDecoration.ITALIC, false);
    }

    public void send(CommandSender to, String key, String... kv) {
        to.sendMessage(component("prefix").append(component(key, kv)));
    }
}
