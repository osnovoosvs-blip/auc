package dev.rtpauction;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class AuctionCommand implements TabExecutor {
    private final RtpAuctionPlugin plugin;

    public AuctionCommand(RtpAuctionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Messages m = plugin.messages();

        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("rtpauction.auction.admin")) {
                m.send(sender, "no-permission");
                return true;
            }
            plugin.reloadConfig();
            m.send(sender, "ah-reload");
            return true;
        }

        if (!(sender instanceof Player p)) {
            m.send(sender, "players-only");
            return true;
        }
        String sub = args.length == 0 ? "open" : args[0].toLowerCase(Locale.ROOT);
        // забрать свои предметы можно и без экономики
        if (plugin.economy() == null && !sub.equals("claim")) {
            m.send(p, "ah-no-economy");
            return true;
        }

        switch (sub) {
            case "sell" -> sell(p, args);
            case "mine" -> plugin.gui().open(p, AuctionGui.Mode.MINE, 0);
            case "claim" -> plugin.auction().claim(p);
            default -> plugin.gui().open(p, AuctionGui.Mode.ALL, 0);
        }
        return true;
    }

    private void sell(Player p, String[] args) {
        Messages m = plugin.messages();
        var c = plugin.getConfig();
        if (args.length < 2) {
            m.send(p, "ah-usage-sell");
            return;
        }
        double price;
        try {
            price = Double.parseDouble(args[1].replace(',', '.'));
        } catch (NumberFormatException ex) {
            m.send(p, "ah-bad-price");
            return;
        }
        double min = c.getDouble("auction.min-price", 1);
        double max = c.getDouble("auction.max-price", 1_000_000_000);
        if (Double.isNaN(price) || Double.isInfinite(price) || price < min || price > max) {
            m.send(p, "ah-price-range", "min", String.valueOf(min), "max", String.valueOf(max));
            return;
        }
        price = Math.round(price * 100.0) / 100.0;

        ItemStack held = p.getInventory().getItemInMainHand();
        if (held.getType().isAir()) {
            m.send(p, "ah-no-item");
            return;
        }
        for (String name : c.getStringList("auction.blacklist")) {
            Material mat = Material.matchMaterial(name);
            if (mat != null && mat == held.getType()) {
                m.send(p, "ah-blacklisted");
                return;
            }
        }
        int limit = c.getInt("auction.max-listings", 5);
        if (!p.hasPermission("rtpauction.auction.unlimited") && plugin.auction().countBy(p.getUniqueId()) >= limit) {
            m.send(p, "ah-limit", "max", String.valueOf(limit));
            return;
        }

        ItemStack toList = held.clone();
        p.getInventory().setItemInMainHand(null);
        plugin.auction().add(p, toList, price);
        m.send(p, "ah-listed", "item", AuctionManager.itemName(toList), "price", plugin.economy().format(price));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("sell", "mine", "claim", "reload")) {
                if (s.equals("reload") && !sender.hasPermission("rtpauction.auction.admin")) continue;
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("sell")) {
            out.add("<цена>");
        }
        return out;
    }
}
