package dev.rtpauction;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class AuctionManager {
    public record Listing(long id, UUID seller, String sellerName, ItemStack item, double price, long expiresAt) {}

    private final RtpAuctionPlugin plugin;
    private final File file;
    private final Map<Long, Listing> listings = new LinkedHashMap<>();
    private final Map<UUID, List<ItemStack>> expired = new HashMap<>();
    private long nextId = 1;

    public AuctionManager(RtpAuctionPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "auctions.yml");
        load();
    }

    // ---------- хранение ----------

    private static String encode(ItemStack item) {
        return Base64.getEncoder().encodeToString(item.serializeAsBytes());
    }

    private static ItemStack decode(String s) {
        return ItemStack.deserializeBytes(Base64.getDecoder().decode(s));
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        nextId = y.getLong("next-id", 1);
        ConfigurationSection ls = y.getConfigurationSection("listings");
        if (ls != null) {
            for (String key : ls.getKeys(false)) {
                ConfigurationSection l = ls.getConfigurationSection(key);
                if (l == null) continue;
                try {
                    long id = Long.parseLong(key);
                    listings.put(id, new Listing(id, UUID.fromString(l.getString("seller")),
                            l.getString("seller-name", "?"), decode(l.getString("item")),
                            l.getDouble("price"), l.getLong("expires")));
                } catch (Exception ex) {
                    plugin.getLogger().warning("Пропущен повреждённый лот " + key + ": " + ex.getMessage());
                }
            }
        }
        ConfigurationSection es = y.getConfigurationSection("expired");
        if (es != null) {
            for (String uuid : es.getKeys(false)) {
                List<ItemStack> items = new ArrayList<>();
                for (String s : es.getStringList(uuid)) {
                    try {
                        items.add(decode(s));
                    } catch (Exception ignored) {
                    }
                }
                if (!items.isEmpty()) expired.put(UUID.fromString(uuid), items);
            }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("next-id", nextId);
        for (Listing l : listings.values()) {
            String p = "listings." + l.id();
            y.set(p + ".seller", l.seller().toString());
            y.set(p + ".seller-name", l.sellerName());
            y.set(p + ".price", l.price());
            y.set(p + ".expires", l.expiresAt());
            y.set(p + ".item", encode(l.item()));
        }
        for (Map.Entry<UUID, List<ItemStack>> e : expired.entrySet()) {
            List<String> list = new ArrayList<>();
            for (ItemStack it : e.getValue()) list.add(encode(it));
            y.set("expired." + e.getKey(), list);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Не удалось сохранить auctions.yml: " + ex.getMessage());
        }
    }

    // ---------- запросы ----------

    public Listing get(long id) {
        return listings.get(id);
    }

    /** Новые лоты первыми. */
    public List<Listing> all() {
        List<Listing> list = new ArrayList<>(listings.values());
        Collections.reverse(list);
        return list;
    }

    public List<Listing> byPlayer(UUID uuid) {
        List<Listing> list = new ArrayList<>();
        for (Listing l : all()) if (l.seller().equals(uuid)) list.add(l);
        return list;
    }

    public int countBy(UUID uuid) {
        int n = 0;
        for (Listing l : listings.values()) if (l.seller().equals(uuid)) n++;
        return n;
    }

    public int expiredCount(UUID uuid) {
        List<ItemStack> list = expired.get(uuid);
        return list == null ? 0 : list.size();
    }

    public static String itemName(ItemStack it) {
        return it.getAmount() + "x " + it.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    // ---------- действия ----------

    public Listing add(Player seller, ItemStack item, double price) {
        long hours = plugin.getConfig().getLong("auction.duration-hours", 48);
        Listing l = new Listing(nextId++, seller.getUniqueId(), seller.getName(), item, price,
                System.currentTimeMillis() + hours * 3_600_000L);
        listings.put(l.id(), l);
        save();
        return l;
    }

    public void buy(Player buyer, long id) {
        Messages m = plugin.messages();
        Economy eco = plugin.economy();
        if (eco == null) {
            m.send(buyer, "ah-no-economy");
            return;
        }
        Listing l = listings.get(id);
        if (l == null) {
            m.send(buyer, "ah-not-found");
            return;
        }
        if (l.seller().equals(buyer.getUniqueId())) {
            m.send(buyer, "ah-own-listing");
            return;
        }
        if (!eco.has(buyer, l.price())) {
            m.send(buyer, "ah-no-money", "price", eco.format(l.price()));
            return;
        }
        if (buyer.getInventory().firstEmpty() == -1) {
            m.send(buyer, "ah-inv-full");
            return;
        }
        if (!eco.withdrawPlayer(buyer, l.price()).transactionSuccess()) {
            m.send(buyer, "ah-no-money", "price", eco.format(l.price()));
            return;
        }
        double tax = plugin.getConfig().getDouble("auction.tax-percent", 0);
        double payout = l.price() * (1.0 - tax / 100.0);
        OfflinePlayer seller = Bukkit.getOfflinePlayer(l.seller());
        eco.depositPlayer(seller, payout);

        listings.remove(id);
        save();
        buyer.getInventory().addItem(l.item().clone());

        String name = itemName(l.item());
        m.send(buyer, "ah-bought", "item", name, "price", eco.format(l.price()));
        Player online = Bukkit.getPlayer(l.seller());
        if (online != null) {
            m.send(online, "ah-sold", "item", name, "buyer", buyer.getName(), "price", eco.format(payout));
        }
    }

    /** Снять лот: владелец или админ. Предмет возвращается в инвентарь, при нехватке места — в /ah claim. */
    public void cancel(Player who, long id) {
        Listing l = listings.get(id);
        if (l == null) {
            plugin.messages().send(who, "ah-not-found");
            return;
        }
        if (!l.seller().equals(who.getUniqueId()) && !who.hasPermission("rtpauction.auction.admin")) {
            plugin.messages().send(who, "no-permission");
            return;
        }
        listings.remove(id);
        if (who.getInventory().firstEmpty() != -1) {
            who.getInventory().addItem(l.item().clone());
        } else {
            expired.computeIfAbsent(l.seller(), k -> new ArrayList<>()).add(l.item().clone());
            plugin.messages().send(who, "ah-inv-full");
        }
        save();
        plugin.messages().send(who, "ah-cancelled", "item", itemName(l.item()));
    }

    public void claim(Player p) {
        Messages m = plugin.messages();
        List<ItemStack> items = expired.remove(p.getUniqueId());
        if (items == null || items.isEmpty()) {
            m.send(p, "ah-claim-none");
            return;
        }
        int given = 0;
        List<ItemStack> rest = new ArrayList<>();
        for (ItemStack it : items) {
            Map<Integer, ItemStack> left = p.getInventory().addItem(it);
            if (left.isEmpty()) given++;
            else rest.addAll(left.values());
        }
        if (!rest.isEmpty()) {
            expired.put(p.getUniqueId(), rest);
            m.send(p, "ah-claim-leftover");
        }
        if (given > 0) m.send(p, "ah-claimed", "count", String.valueOf(given));
        save();
    }

    /** Просроченные лоты уходят в список возврата владельца. */
    public void purgeExpired() {
        long now = System.currentTimeMillis();
        boolean changed = false;
        Iterator<Listing> it = listings.values().iterator();
        while (it.hasNext()) {
            Listing l = it.next();
            if (l.expiresAt() > now) continue;
            it.remove();
            changed = true;
            expired.computeIfAbsent(l.seller(), k -> new ArrayList<>()).add(l.item());
            Player online = Bukkit.getPlayer(l.seller());
            if (online != null) plugin.messages().send(online, "ah-expired-notify", "item", itemName(l.item()));
        }
        if (changed) save();
    }
}
