# RtpAuction (Paper 1.21+, Java 21)

Плагин: **/rtp** (случайная телепортация), **/spawn** + **/setspawn** и **/ah** (аукцион игроков с GUI).
Нужен Vault + любой плагин экономики для аукциона и платного RTP.

## Сборка
    mvn clean package
Готовый jar: `target/RtpAuction-1.3.0.jar` → в папку `plugins/`.

## Команды
| Команда | Что делает |
|---|---|
| /rtp | случайная телепортация (кулдаун, задержка, цена — в config.yml) |
| /spawn | телепорт на спавн (задержка/кулдаун — в config.yml) |
| /setspawn | установить спавн в вашей позиции (админ) |
| (авто) таб-лист | шапка/подвал: ник, баланс, пинг, онлайн, TPS — блок `tab:` в config.yml |
| (авто) деньги за мобов | суммы по типам мобов — блок `mob-rewards:` в config.yml |
| /ah | открыть аукцион (ЛКМ по лоту — купить) |
| /ah sell <цена> | выставить предмет из основной руки |
| /ah mine | мои лоты (ЛКМ — снять) |
| /ah claim | забрать просроченные/возвращённые предметы |
| /ahnpc set | поставить NPC-аукциониста на своё место (админ); ПКМ по нему открывает аукцион |
| /ahnpc remove | убрать NPC (админ) |
| /ah reload | перезагрузка конфига (админ) |

## Права
rtpauction.rtp, rtpauction.rtp.bypass, rtpauction.spawn, rtpauction.spawn.set,
rtpauction.spawn.bypass, rtpauction.mobreward, rtpauction.auction,
rtpauction.auction.unlimited, rtpauction.auction.admin, rtpauction.npc

## Скин NPC
NPC — это Mannequin (Minecraft 1.21.9+). Скин задаётся в блоке `npc.skin` в config.yml:
- `value` + `signature` — подписанный скин с mineskin.org (загрузить PNG → скопировать значения), либо
- `texture: "rtpauction:entity/auction_npc"` — текстура из ресурспака сервера (готовый пак: AuctionNpcSkin_resourcepack.zip).
После правки конфига: `/ah reload`, затем `/ahnpc set` заново.
