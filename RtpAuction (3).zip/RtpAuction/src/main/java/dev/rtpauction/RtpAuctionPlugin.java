package dev.rtpauction;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class RtpAuctionPlugin extends JavaPlugin implements Listener {
    private Economy economy;
    private Messages messages;
    private RtpManager rtp;
    private SpawnManager spawn;
    private NpcManager npc;
    private TabManager tab;
    private AuctionManager auction;
    private AuctionGui gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        messages = new Messages(this);
        rtp = new RtpManager(this);
        spawn = new SpawnManager(this);
        npc = new NpcManager(this);
        tab = new TabManager(this);
        auction = new AuctionManager(this);
        gui = new AuctionGui(this);

        getCommand("rtp").setExecutor(new RtpCommand(this));
        getCommand("spawn").setExecutor(new SpawnCommand(this));
        getCommand("setspawn").setExecutor(new SetSpawnCommand(this));
        getCommand("ahnpc").setExecutor(new NpcCommand(this));
        AuctionCommand ah = new AuctionCommand(this);
        getCommand("ah").setExecutor(ah);
        getCommand("ah").setTabCompleter(ah);

        getServer().getPluginManager().registerEvents(gui, this);
        getServer().getPluginManager().registerEvents(spawn, this);
        getServer().getPluginManager().registerEvents(npc, this);
        getServer().getPluginManager().registerEvents(tab, this);
        getServer().getPluginManager().registerEvents(new MobRewardListener(this), this);
        tab.start();
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getScheduler().runTaskTimer(this, () -> auction.purgeExpired(), 1200L, 1200L);

        if (economy() == null) {
            getLogger().warning("Vault/экономика не найдены: аукцион отключён, RTP работает бесплатно.");
        }
    }

    @Override
    public void onDisable() {
        if (auction != null) auction.save();
    }

    /** Экономика ищется лениво: плагин экономики может загрузиться позже нас. */
    public Economy economy() {
        if (economy == null && getServer().getPluginManager().getPlugin("Vault") != null) {
            RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
            if (rsp != null) economy = rsp.getProvider();
        }
        return economy;
    }

    public Messages messages() { return messages; }
    public RtpManager rtp() { return rtp; }
    public SpawnManager spawn() { return spawn; }
    public NpcManager npc() { return npc; }
    public AuctionManager auction() { return auction; }
    public AuctionGui gui() { return gui; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        var p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            int n = auction.expiredCount(p.getUniqueId());
            if (p.isOnline() && n > 0) messages.send(p, "ah-expired-notice", "count", String.valueOf(n));
        }, 40L);
    }
}
